@echo off
:: Ask for admin rights if we don't have them
net session >nul 2>&1
if %errorlevel% neq 0 (
  powershell -Command "Start-Process '%~f0' -Verb RunAs"
  exit /b
)

set IP=192.168.2.10
set PNAME=Smith Walsingham Advanced
set DRIVER=KONICA MINOLTA Universal PCL
set DRVDIR=driver

echo Installing driver...
pnputil /add-driver "%~dp0%DRVDIR%\*.inf" /install >nul

echo Adding printer...
powershell -NoProfile -Command ^
 "Add-PrinterDriver -Name '%DRIVER%';" ^
 "if (-not (Get-PrinterPort -Name 'IP_%IP%' -EA SilentlyContinue)) { Add-PrinterPort -Name 'IP_%IP%' -PrinterHostAddress '%IP%' -SNMP 1 -SNMPCommunity 'public' };" ^
 "if (-not (Get-Printer -Name '%PNAME%' -EA SilentlyContinue)) { Add-Printer -Name '%PNAME%' -DriverName '%DRIVER%' -PortName 'IP_%IP%' }"

if %errorlevel% equ 0 (echo Done. Printer is ready.) else (echo Something went wrong.)
pause
