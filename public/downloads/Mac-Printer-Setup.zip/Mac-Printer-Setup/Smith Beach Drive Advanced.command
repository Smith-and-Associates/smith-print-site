#!/bin/bash
# Adds the Smith Beach Drive Advanced printer (192.168.5.10)
NAME="Smith Beach Drive Advanced"
QUEUE="Smith_Beach_Drive_Advanced"
IP="192.168.5.10"

echo "Adding $NAME..."
lpadmin -p "$QUEUE" -D "$NAME" -E -v "ipp://$IP/ipp" -m everywhere -o printer-is-shared=false
if [ $? -eq 0 ]; then
  echo "Done. $NAME is ready."
else
  echo "Something went wrong. Make sure you're on the office network."
fi
read -p "Press Enter to close."
