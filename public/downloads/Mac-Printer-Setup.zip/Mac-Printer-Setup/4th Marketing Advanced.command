#!/bin/bash
# Adds the 4th Marketing Advanced printer (192.168.3.202)
NAME="4th Marketing Advanced"
QUEUE="4th_Marketing_Advanced"
IP="192.168.3.202"

echo "Adding $NAME..."
lpadmin -p "$QUEUE" -D "$NAME" -E -v "ipp://$IP/ipp" -m everywhere -o printer-is-shared=false
if [ $? -eq 0 ]; then
  echo "Done. $NAME is ready."
else
  echo "Something went wrong. Make sure you're on the office network."
fi
read -p "Press Enter to close."
