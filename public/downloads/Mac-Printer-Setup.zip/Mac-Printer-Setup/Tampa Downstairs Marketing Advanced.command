#!/bin/bash
# Adds the Tampa Downstairs Marketing Advanced printer (192.168.1.49)
NAME="Tampa Downstairs Marketing Advanced"
QUEUE="Tampa_Downstairs_Marketing_Advanced"
IP="192.168.1.49"

echo "Adding $NAME..."
lpadmin -p "$QUEUE" -D "$NAME" -E -v "ipp://$IP/ipp" -m everywhere -o printer-is-shared=false
if [ $? -eq 0 ]; then
  echo "Done. $NAME is ready."
else
  echo "Something went wrong. Make sure you're on the office network."
fi
read -p "Press Enter to close."
