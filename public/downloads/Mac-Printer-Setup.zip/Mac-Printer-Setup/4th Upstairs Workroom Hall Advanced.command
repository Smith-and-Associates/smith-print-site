#!/bin/bash
# Adds the 4th Upstairs Workroom Hall Advanced printer (192.168.3.110)
NAME="4th Upstairs Workroom Hall Advanced"
QUEUE="4th_Upstairs_Workroom_Hall_Advanced"
IP="192.168.3.110"

echo "Adding $NAME..."
lpadmin -p "$QUEUE" -D "$NAME" -E -v "ipp://$IP/ipp" -m everywhere -o printer-is-shared=false
if [ $? -eq 0 ]; then
  echo "Done. $NAME is ready."
else
  echo "Something went wrong. Make sure you're on the office network."
fi
read -p "Press Enter to close."
